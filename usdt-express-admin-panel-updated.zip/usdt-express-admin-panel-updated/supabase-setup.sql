-- USDT Express: Supabase SQL Editor में पूरा SQL चलाएँ.
-- Public visitors can read the single settings row. Only user IDs in admin_users can update it.
create table if not exists public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

create table if not exists public.site_settings (
  id integer primary key check (id = 1),
  buy_rate numeric(12,2) not null default 100 check (buy_rate >= 0),
  sell_rate numeric(12,2) not null default 96 check (sell_rate >= 0),
  upi_id text not null default '',
  trc20_address text not null default '',
  bep20_address text not null default '',
  erc20_address text not null default '',
  qr_path text,
  updated_at timestamptz not null default now()
);

alter table public.site_settings add column if not exists trc20_address text not null default '';
alter table public.site_settings add column if not exists bep20_address text not null default '';
alter table public.site_settings add column if not exists erc20_address text not null default '';

insert into public.site_settings (id, buy_rate, sell_rate, upi_id)
values (1, 100, 96, '')
on conflict (id) do nothing;

alter table public.admin_users enable row level security;
alter table public.site_settings enable row level security;

create or replace function public.is_usdt_express_admin()
returns boolean
language sql
security definer
stable
set search_path = ''
as $$
  select exists (
    select 1 from public.admin_users
    where user_id = (select auth.uid())
  );
$$;

revoke all on function public.is_usdt_express_admin() from public;
grant execute on function public.is_usdt_express_admin() to authenticated;

drop policy if exists "Admin can read own admin membership" on public.admin_users;
create policy "Admin can read own admin membership"
on public.admin_users for select to authenticated
using (user_id = (select auth.uid()));

drop policy if exists "Public can read site settings" on public.site_settings;
create policy "Public can read site settings"
on public.site_settings for select to anon, authenticated
using (id = 1);

drop policy if exists "Only admins can insert site settings" on public.site_settings;
create policy "Only admins can insert site settings"
on public.site_settings for insert to authenticated
with check (public.is_usdt_express_admin() and id = 1);

drop policy if exists "Only admins can update site settings" on public.site_settings;
create policy "Only admins can update site settings"
on public.site_settings for update to authenticated
using (public.is_usdt_express_admin() and id = 1)
with check (public.is_usdt_express_admin() and id = 1);

-- Create a PUBLIC bucket because customers must see the QR image.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('payment-qr', 'payment-qr', true, 3145728, array['image/png','image/jpeg','image/webp'])
on conflict (id) do update set public = true, file_size_limit = 3145728,
  allowed_mime_types = array['image/png','image/jpeg','image/webp'];

drop policy if exists "Admins can upload payment QR" on storage.objects;
create policy "Admins can upload payment QR"
on storage.objects for insert to authenticated
with check (bucket_id = 'payment-qr' and public.is_usdt_express_admin());

drop policy if exists "Admins can update payment QR" on storage.objects;
create policy "Admins can update payment QR"
on storage.objects for update to authenticated
using (bucket_id = 'payment-qr' and public.is_usdt_express_admin())
with check (bucket_id = 'payment-qr' and public.is_usdt_express_admin());

-- Public bucket makes images readable; no public upload/update/delete policies are created.
