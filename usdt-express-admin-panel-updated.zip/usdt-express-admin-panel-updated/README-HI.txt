USDT EXPRESS — SECURE ADMIN PANEL (Netlify + Supabase)
======================================================

Included:
- index.html: customer site, Buy ₹100 / Sell ₹96 defaults, WhatsApp order enquiry.
- admin.html: login, change UPI ID, upload/replace payment QR, edit rates, and configure TRC20/BEP20/ERC20 wallet addresses.
- supabase-setup.sql: database + Row Level Security + QR storage policies.

IMPORTANT: This is a starter package. It will NOT persist changes until you configure Supabase.
Do not put a Supabase service_role/secret key into any HTML file. Only use the public anon/publishable key.

SETUP (do this once)
--------------------
1. Create a Supabase project at https://supabase.com/
2. Open Project Settings -> API. Copy the Project URL and public anon/publishable key.
3. Open SQL Editor in Supabase, paste all of supabase-setup.sql, and Run it.
4. In Authentication -> Users, create your own admin user with an email/password. Disable public sign-ups in Authentication settings after creating your account.
5. Copy your new admin user's UUID from Authentication -> Users.
6. In SQL Editor, run this command after replacing YOUR-USER-UUID:
   insert into public.admin_users (user_id) values ('YOUR-USER-UUID');
   Do NOT insert any customer's user ID here.
7. In BOTH index.html and admin.html, replace:
   PASTE_SUPABASE_URL_HERE with your Project URL
   PASTE_SUPABASE_ANON_KEY_HERE with your public anon/publishable key
   Never use service_role / secret key.
8. Check the WhatsApp number in index.html. It is currently set to 917261026729 (country code + digits only); change it if this is not the correct order number.
9. Upload index.html, admin.html, and any other files from this folder to the SAME Netlify site (site deploy / drag-and-drop). Keep index.html at the root.
10. Open https://YOUR-SITE.netlify.app/admin.html and log in using the admin account.
11. Save UPI ID, upload a QR image, and click Save Settings. Open the public site in another tab to verify.

SECURITY NOTES
--------------
- RLS policies protect database writes and QR uploads to authorized admin user IDs.
- The public QR bucket is readable by customers by design; upload only a QR you intend to share publicly.
- Public UPI ID and QR can be copied by visitors. Do not upload personal or unrelated bank information.
- A QR upload updates the site settings immediately; no Netlify redeploy is needed for future UPI/QR changes.
- This site does NOT verify payment, UTR, blockchain transactions, or automatically release USDT. The WhatsApp form is an order enquiry; verify UTR/TxID manually before fulfilling an order. Do not display "Payment Successful" without independent payment verification.
- Keep the admin email and password private; enable MFA if available.
- This package is not a legal or compliance assessment. Confirm applicable Indian rules and payment-provider terms before operating a digital-asset service.

If login says permission denied, confirm the signed-in user's UUID exists in public.admin_users and the SQL ran successfully.

NETWORK / PAYMENT FLOW
----------------------
- Admin panel supports TRC20 (TRON), BEP20 (BNB Smart Chain), and optional ERC20 (Ethereum) receiving addresses.
- After running the SQL, update both HTML files with the Supabase Project URL and public publishable/anon key, then deploy the files to Netlify.
- Log into /admin.html, enter the correct wallet address for each network, and save. No real wallet address is prefilled.
- Customer selects the network and contacts the seller on WhatsApp. Confirm the network/address and verify the transaction independently before marking any order complete.
- Do not paste a secret/service-role key into these files.
